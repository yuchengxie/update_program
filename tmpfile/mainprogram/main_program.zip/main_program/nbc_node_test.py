'''
Description: 
Version: 1.0
Author: xieyucheng
Date: 2021-06-01 09:50:00
LastEditors: xieyucheng
LastEditTime: 2021-06-01 14:20:48
'''
from flask import Flask

app = Flask(__name__)


if __name__ == '__main__':
    print('hello')
    # app.run(host='0.0.0.0', port=5001)
